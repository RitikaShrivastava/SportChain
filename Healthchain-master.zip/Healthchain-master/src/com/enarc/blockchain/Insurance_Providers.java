package com.enarc.blockchain;

public enum Insurance_Providers
{
	Blue_Cross_Blue_Shield(), United_Health(), Wellpoint(), Kaiser(), Humana(), Aetna(), HSCS(), Cigna(), XYZ(), Other();
}
